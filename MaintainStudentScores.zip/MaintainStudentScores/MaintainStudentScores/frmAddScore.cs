﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaintainStudentScores
{
    public partial class frmAddScore : Form
    {
        private frmUpdateStudent parentForm;

        public frmAddScore(frmUpdateStudent parentForm)
        {
            this.parentForm = parentForm; //allow adding score to previous student selected
            InitializeComponent();
        }

        private void CancelButton1_Click(object sender, EventArgs e)
        {
            Close();  //close form
        }

        private void AddScoreButton_Click_1(object sender, EventArgs e)
        {
            parentForm.AddScoreToStudent(Convert.ToInt32(ScoreValue.Text));  //add score to current student (from previous form)
            Close();
        }

    }
}
