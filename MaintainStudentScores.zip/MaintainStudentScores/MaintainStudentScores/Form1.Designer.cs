﻿namespace MaintainStudentScores
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExitButton = new System.Windows.Forms.Button();
            this.ScoreCount = new System.Windows.Forms.Label();
            this.ScoreAverage = new System.Windows.Forms.Label();
            this.ScoreTotal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.deleteStudent = new System.Windows.Forms.Button();
            this.updateStudent = new System.Windows.Forms.Button();
            this.addStudent = new System.Windows.Forms.Button();
            this.students = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ScoreTotalTextBox = new System.Windows.Forms.TextBox();
            this.ScoreCountTextBox = new System.Windows.Forms.TextBox();
            this.ScoreAverageTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(184, 232);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 28);
            this.ExitButton.TabIndex = 23;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click_1);
            // 
            // ScoreCount
            // 
            this.ScoreCount.AutoSize = true;
            this.ScoreCount.Location = new System.Drawing.Point(124, 210);
            this.ScoreCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ScoreCount.Name = "ScoreCount";
            this.ScoreCount.Size = new System.Drawing.Size(0, 17);
            this.ScoreCount.TabIndex = 22;
            // 
            // ScoreAverage
            // 
            this.ScoreAverage.AutoSize = true;
            this.ScoreAverage.Location = new System.Drawing.Point(124, 238);
            this.ScoreAverage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ScoreAverage.Name = "ScoreAverage";
            this.ScoreAverage.Size = new System.Drawing.Size(0, 17);
            this.ScoreAverage.TabIndex = 21;
            // 
            // ScoreTotal
            // 
            this.ScoreTotal.AutoSize = true;
            this.ScoreTotal.Location = new System.Drawing.Point(124, 183);
            this.ScoreTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ScoreTotal.Name = "ScoreTotal";
            this.ScoreTotal.Size = new System.Drawing.Size(0, 17);
            this.ScoreTotal.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 210);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "Score Count";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 238);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "Average";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 183);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Score Total";
            // 
            // deleteStudent
            // 
            this.deleteStudent.Location = new System.Drawing.Point(184, 113);
            this.deleteStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.deleteStudent.Name = "deleteStudent";
            this.deleteStudent.Size = new System.Drawing.Size(100, 28);
            this.deleteStudent.TabIndex = 16;
            this.deleteStudent.Text = "Delete...";
            this.deleteStudent.UseVisualStyleBackColor = true;
            this.deleteStudent.Click += new System.EventHandler(this.deleteStudent_Click_1);
            // 
            // updateStudent
            // 
            this.updateStudent.Location = new System.Drawing.Point(183, 78);
            this.updateStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.updateStudent.Name = "updateStudent";
            this.updateStudent.Size = new System.Drawing.Size(100, 28);
            this.updateStudent.TabIndex = 15;
            this.updateStudent.Text = "Update...";
            this.updateStudent.UseVisualStyleBackColor = true;
            this.updateStudent.Click += new System.EventHandler(this.updateStudent_Click_1);
            // 
            // addStudent
            // 
            this.addStudent.Location = new System.Drawing.Point(184, 42);
            this.addStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addStudent.Name = "addStudent";
            this.addStudent.Size = new System.Drawing.Size(100, 28);
            this.addStudent.TabIndex = 14;
            this.addStudent.Text = "Add...";
            this.addStudent.UseVisualStyleBackColor = true;
            this.addStudent.Click += new System.EventHandler(this.addStudent_Click);
            // 
            // students
            // 
            this.students.FormattingEnabled = true;
            this.students.ItemHeight = 16;
            this.students.Location = new System.Drawing.Point(16, 42);
            this.students.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.students.Name = "students";
            this.students.Size = new System.Drawing.Size(159, 132);
            this.students.TabIndex = 13;
            this.students.SelectedIndexChanged += new System.EventHandler(this.students_SelectedIndexChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Students:";
            // 
            // ScoreTotalTextBox
            // 
            this.ScoreTotalTextBox.Location = new System.Drawing.Point(107, 180);
            this.ScoreTotalTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ScoreTotalTextBox.Name = "ScoreTotalTextBox";
            this.ScoreTotalTextBox.ReadOnly = true;
            this.ScoreTotalTextBox.Size = new System.Drawing.Size(68, 22);
            this.ScoreTotalTextBox.TabIndex = 24;
            // 
            // ScoreCountTextBox
            // 
            this.ScoreCountTextBox.Location = new System.Drawing.Point(107, 207);
            this.ScoreCountTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ScoreCountTextBox.Name = "ScoreCountTextBox";
            this.ScoreCountTextBox.ReadOnly = true;
            this.ScoreCountTextBox.Size = new System.Drawing.Size(68, 22);
            this.ScoreCountTextBox.TabIndex = 25;
            // 
            // ScoreAverageTextBox
            // 
            this.ScoreAverageTextBox.Location = new System.Drawing.Point(107, 238);
            this.ScoreAverageTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ScoreAverageTextBox.Name = "ScoreAverageTextBox";
            this.ScoreAverageTextBox.ReadOnly = true;
            this.ScoreAverageTextBox.Size = new System.Drawing.Size(68, 22);
            this.ScoreAverageTextBox.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 282);
            this.Controls.Add(this.ScoreAverageTextBox);
            this.Controls.Add(this.ScoreCountTextBox);
            this.Controls.Add(this.ScoreTotalTextBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ScoreCount);
            this.Controls.Add(this.ScoreAverage);
            this.Controls.Add(this.ScoreTotal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.deleteStudent);
            this.Controls.Add(this.updateStudent);
            this.Controls.Add(this.addStudent);
            this.Controls.Add(this.students);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label ScoreCount;
        private System.Windows.Forms.Label ScoreAverage;
        private System.Windows.Forms.Label ScoreTotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button deleteStudent;
        private System.Windows.Forms.Button updateStudent;
        private System.Windows.Forms.Button addStudent;
        private System.Windows.Forms.ListBox students;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ScoreTotalTextBox;
        private System.Windows.Forms.TextBox ScoreCountTextBox;
        private System.Windows.Forms.TextBox ScoreAverageTextBox;

    }
}